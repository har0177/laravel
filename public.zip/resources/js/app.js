import './bootstrap';
import Alpine from 'alpinejs';
import focus from '@alpinejs/focus';
Alpine.plugin(focus);

Alpine.start();


