@include('header')

@include('navbar')
<div class="container-fluid pt-2">
	Will be updated Soon.
</div>
@include('footer')