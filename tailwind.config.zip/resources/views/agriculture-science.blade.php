@include('header')

@include('navbar')
<div class="container-fluid pt-2">
	<img src="{{asset('das/1.jpg')}}" width="100%"/>
	<img src="{{asset('das/2.jpg')}}" width="100%"/>
	<img src="{{asset('das/3.jpg')}}" width="100%"/>
</div>
@include('footer')