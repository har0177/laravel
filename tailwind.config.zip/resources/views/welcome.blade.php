@include('header')

@include('navbar')
@livewire('home-page')
@include('footer')
