<?php

namespace App\Enums;

enum ReligionEnum: string
{
  case Islam = 'Islam';
  case Minority = 'Minority';
}