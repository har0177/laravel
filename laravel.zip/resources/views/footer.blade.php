
<!-- Footer -->
<footer class="container-fluid p-4 bg-color">
	<p class="copyright clearfix">
		© Designed and Maintained by
		<a href="https://xpertzdev.com/">Xpertz Dev IT Solution</a>
	</p>
</footer>
<!-- Bootstrap Links -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="https://kit.fontawesome.com/2ab307e440.js" crossorigin="anonymous"></script>


</body>
</html>