@include('header')

@include('navbar')
<div class="container-fluid pt-2">
	<img src="{{asset('dvs/1.jpg')}}" width="100%"/>
	<img src="{{asset('dvs/2.jpg')}}" width="100%"/>
	<img src="{{asset('dvs/3.jpg')}}" width="100%"/>
</div>
@include('footer')