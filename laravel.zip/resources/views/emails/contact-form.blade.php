<!doctype html>
<html>
<head>
	<meta name="viewport" content="width=device-width"/>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<title>Agriculture Services Academy</title>
</head>
<body class="">
<p>From: {{ $name }}</p>
<p>{!! $body !!}</p>
</body>
</html>
