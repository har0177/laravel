@include('header')

@include('navbar')
<div class="container-fluid pt-2">
	<img src="{{asset('fee-structure.jpg')}}" width="100%"/>
</div>
@include('footer')